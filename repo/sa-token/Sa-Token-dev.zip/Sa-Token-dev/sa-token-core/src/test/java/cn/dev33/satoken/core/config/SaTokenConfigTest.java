/*
 * Copyright 2020-2099 sa-token.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package cn.dev33.satoken.core.config;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import cn.dev33.satoken.config.SaCookieConfig;
import cn.dev33.satoken.config.SaTokenConfig;
import cn.dev33.satoken.config.SaTokenConfigFactory;
import cn.dev33.satoken.error.SaErrorCode;
import cn.dev33.satoken.exception.SaTokenException;
import cn.dev33.satoken.stp.parameter.enums.SaLogoutMode;
import cn.dev33.satoken.stp.parameter.enums.SaLogoutRange;
import cn.dev33.satoken.stp.parameter.enums.SaReplacedLoginExitMode;
import cn.dev33.satoken.stp.parameter.enums.SaReplacedRange;

import java.util.LinkedHashMap;

/**
 * 配置类测试 
 * 
 * @author click33
 * @since 2022-9-4
 */
public class SaTokenConfigTest {

	// 基本 get set 测试
	/** SaTokenConfig 基本属性 getter/setter 应正常工作 */
	@Test
	public void testProp() {
		SaTokenConfig config = new SaTokenConfig();
		
		config.setTokenName("nav-token");
		Assertions.assertEquals("nav-token", config.getTokenName());

		config.setTimeout(100204);
		Assertions.assertEquals(100204, config.getTimeout());

		config.setActiveTimeout(1804);
		Assertions.assertEquals(1804, config.getActiveTimeout());

		config.setIsConcurrent(false);
		Assertions.assertEquals(false, config.getIsConcurrent());

		config.setIsShare(false);
		Assertions.assertEquals(false, config.getIsShare());

		config.setMaxLoginCount(11);
		Assertions.assertEquals(11, config.getMaxLoginCount());

		config.setIsReadBody(false);
		Assertions.assertEquals(false, config.getIsReadBody());

		config.setIsReadHeader(false);
		Assertions.assertEquals(false, config.getIsReadHeader());

		config.setIsReadCookie(false);
		Assertions.assertEquals(false, config.getIsReadCookie());

		config.setTokenStyle("tik");
		Assertions.assertEquals("tik", config.getTokenStyle());

		config.setDataRefreshPeriod(111);
		Assertions.assertEquals(111, config.getDataRefreshPeriod());

		config.setTokenSessionCheckLogin(false);
		Assertions.assertEquals(false, config.getTokenSessionCheckLogin());

		config.setAutoRenew(false);
		Assertions.assertEquals(false, config.getAutoRenew());

		config.setTokenPrefix("token");
		Assertions.assertEquals("token", config.getTokenPrefix());

		config.setIsPrint(false);
		Assertions.assertEquals(false, config.getIsPrint());

		config.setIsLog(false);
		Assertions.assertEquals(false, config.getIsLog());

		config.setJwtSecretKey("NgdfaXasARggr");
		Assertions.assertEquals("NgdfaXasARggr", config.getJwtSecretKey());

		config.setSameTokenTimeout(1004);
		Assertions.assertEquals(1004, config.getSameTokenTimeout());

		config.setHttpBasic("sa:123456");
		Assertions.assertEquals("sa:123456", config.getHttpBasic());

		config.setCurrDomain("http://127.0.0.1:8084");
		Assertions.assertEquals("http://127.0.0.1:8084", config.getCurrDomain());

		config.setCheckSameToken(false);
		Assertions.assertEquals(false, config.getCheckSameToken());

		config.setAllowLoginIdColon(true);
		Assertions.assertEquals(true, config.getAllowLoginIdColon());

		SaCookieConfig scc = new SaCookieConfig();
		config.setCookie(scc);
		Assertions.assertEquals(scc, config.getCookie());
		
		config.toString();
	}

	// 从文件读取 
	/** 应从 properties 文件创建 SaTokenConfig */
	@Test
	public void testSaTokenConfigFactory() {
		SaTokenConfig config = SaTokenConfigFactory.createConfig("sa-token2.properties");
		Assertions.assertEquals("use-token", config.getTokenName());
		Assertions.assertEquals(9000, config.getTimeout());
		Assertions.assertEquals(240, config.getActiveTimeout());
		Assertions.assertEquals(false, config.getIsConcurrent());
		Assertions.assertEquals(false, config.getIsShare());
		Assertions.assertEquals(true, config.getIsLog());
	}

	// 测试 SaCookieConfig 
	/** SaCookieConfig 基本属性 getter/setter 应正常工作 */
	@Test
	public void testSaCookieConfig() {
		SaCookieConfig config = new SaCookieConfig();
		
		config.setDomain("stp.cn");
		Assertions.assertEquals("stp.cn", config.getDomain());

		config.setPath("/pro/");
		Assertions.assertEquals("/pro/", config.getPath());

		config.setSecure(true);
		Assertions.assertEquals(true, config.getSecure());

		config.setHttpOnly(false);
		Assertions.assertEquals(false, config.getHttpOnly());

		config.setSameSite("lax");
		Assertions.assertEquals("lax", config.getSameSite());

	}

	/** 扩展字段的 getter/setter 应正常工作 */
	@Test
	void remainingFieldsGetSet() {
		SaTokenConfig config = new SaTokenConfig();

		config.setDynamicActiveTimeout(true);
		Assertions.assertTrue(config.getDynamicActiveTimeout());

		config.setReplacedLoginExitMode(SaReplacedLoginExitMode.NEW_DEVICE);
		Assertions.assertEquals(SaReplacedLoginExitMode.NEW_DEVICE, config.getReplacedLoginExitMode());

		config.setReplacedRange(SaReplacedRange.ALL_DEVICE_TYPE);
		Assertions.assertEquals(SaReplacedRange.ALL_DEVICE_TYPE, config.getReplacedRange());

		config.setOverflowLogoutMode(SaLogoutMode.KICKOUT);
		Assertions.assertEquals(SaLogoutMode.KICKOUT, config.getOverflowLogoutMode());

		config.setMaxTryTimes(7);
		Assertions.assertEquals(7, config.getMaxTryTimes());

		config.setIsLastingCookie(false);
		Assertions.assertFalse(config.getIsLastingCookie());

		config.setIsWriteHeader(true);
		Assertions.assertTrue(config.getIsWriteHeader());

		config.setLogoutRange(SaLogoutRange.ACCOUNT);
		Assertions.assertEquals(SaLogoutRange.ACCOUNT, config.getLogoutRange());

		config.setIsLogoutKeepFreezeOps(true);
		Assertions.assertTrue(config.getIsLogoutKeepFreezeOps());

		config.setIsLogoutKeepTokenSession(true);
		Assertions.assertTrue(config.getIsLogoutKeepTokenSession());

		config.setRightNowCreateTokenSession(true);
		Assertions.assertTrue(config.getRightNowCreateTokenSession());

		config.setCookieAutoFillPrefix(true);
		Assertions.assertTrue(config.getCookieAutoFillPrefix());

		config.setLogLevel("warn");
		Assertions.assertEquals("warn", config.getLogLevel());
		Assertions.assertEquals(4, config.getLogLevelInt());

		config.setLogLevelInt(2);
		Assertions.assertEquals("debug", config.getLogLevel());
		Assertions.assertEquals(2, config.getLogLevelInt());

		config.setIsColorLog(true);
		Assertions.assertTrue(config.getIsColorLog());

		config.setHttpDigest("digest:secret");
		Assertions.assertEquals("digest:secret", config.getHttpDigest());

		config.getCookie()
				.setDomain("sso.example.com")
				.setPath("/sso")
				.setSecure(true)
				.setHttpOnly(true)
				.setSameSite("none")
				.setExtraAttrs(new LinkedHashMap<>());
		SaCookieConfig cookie = config.getCookie();
		Assertions.assertEquals("sso.example.com", cookie.getDomain());
		Assertions.assertEquals("/sso", cookie.getPath());
		Assertions.assertTrue(cookie.getSecure());
		Assertions.assertTrue(cookie.getHttpOnly());
		Assertions.assertEquals("none", cookie.getSameSite());
		Assertions.assertNotNull(cookie.getExtraAttrs());

		Assertions.assertTrue(config.toString().contains("httpDigest=digest:secret"));
		Assertions.assertTrue(config.toString().contains("logoutRange=ACCOUNT"));
	}

	/** 废弃别名方法应映射到对应新字段 */
	@Test
	void deprecatedAliasMethods() {
		SaTokenConfig config = new SaTokenConfig();
		config.setActivityTimeout(900);
		Assertions.assertEquals(900, config.getActivityTimeout());
		Assertions.assertEquals(900, config.getActiveTimeout());

		config.setBasic("admin:pwd");
		Assertions.assertEquals("admin:pwd", config.getBasic());
		Assertions.assertEquals("admin:pwd", config.getHttpBasic());
	}

	/** 默认路径不存在配置文件时应保留 SaTokenConfig 默认值 */
	@Test
	void configFactory_defaultPathUsesDefaults() {
		SaTokenConfig config = SaTokenConfigFactory.createConfig();

		Assertions.assertEquals("satoken", config.getTokenName());
		Assertions.assertEquals(60 * 60 * 24 * 30, config.getTimeout());
		Assertions.assertTrue(config.getIsConcurrent());
	}

	/** 指定不存在的配置文件时应返回默认配置 */
	@Test
	void configFactory_missingFileUsesDefaults() {
		SaTokenConfig config = SaTokenConfigFactory.createConfig("missing-sa-token.properties");

		Assertions.assertEquals("uuid", config.getTokenStyle());
		Assertions.assertEquals(-1, config.getActiveTimeout());
		Assertions.assertFalse(config.getIsShare());
	}

	/** 非法属性值应被包装为配置赋值异常 */
	@Test
	void configFactory_invalidPropertyThrows() {
		SaTokenException ex = Assertions.assertThrows(SaTokenException.class,
				() -> SaTokenConfigFactory.createConfig("sa-token-invalid.properties"));

		Assertions.assertEquals(SaErrorCode.CODE_10022, ex.getCode());
		Assertions.assertTrue(ex.getMessage().contains("timeout"));
	}
	
}
