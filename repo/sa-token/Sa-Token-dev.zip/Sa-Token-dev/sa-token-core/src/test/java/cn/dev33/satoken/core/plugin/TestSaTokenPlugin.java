/*
 * Copyright 2020-2099 sa-token.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package cn.dev33.satoken.core.plugin;

import cn.dev33.satoken.plugin.SaTokenPlugin;

/**
 * 单测 SPI 插件
 *
 * @author click33
 * @since 1.46.0
 */
public class TestSaTokenPlugin implements SaTokenPlugin {

	static volatile boolean installed;

	/** 把安装标记清掉，方便下一个用例重新装插件 */
	public static void reset() {
		installed = false;
	}

	/** 标记这个测试插件已经装上了 */
	@Override
	public void install() {
		installed = true;
	}

}
