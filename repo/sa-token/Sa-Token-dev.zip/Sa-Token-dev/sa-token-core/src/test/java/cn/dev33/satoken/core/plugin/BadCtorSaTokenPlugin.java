/*
 * Copyright 2020-2099 sa-token.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package cn.dev33.satoken.core.plugin;

import cn.dev33.satoken.plugin.SaTokenPlugin;

/**
 * 无无参构造器的插件，用于 installPlugin(Class) 异常路径测试
 *
 * @author click33
 * @since 1.46.0
 */
public class BadCtorSaTokenPlugin implements SaTokenPlugin {

	public BadCtorSaTokenPlugin(String ignored) {
	}

	/** 空实现：这个插件只用来测构造失败，装上时什么都不做 */
	@Override
	public void install() {
	}

	/** 空实现：卸载时同样什么都不做 */
	@Override
	public void destroy() {
	}
}
