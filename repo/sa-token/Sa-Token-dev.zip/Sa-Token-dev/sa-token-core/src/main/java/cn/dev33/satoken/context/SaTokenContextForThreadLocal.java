/*
 * Copyright 2020-2099 sa-token.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package cn.dev33.satoken.context;

import cn.dev33.satoken.context.model.SaRequest;
import cn.dev33.satoken.context.model.SaResponse;
import cn.dev33.satoken.context.model.SaStorage;
import cn.dev33.satoken.context.model.SaTokenContextModelBox;

/**
 * Sa-Token 上下文处理器 [ ThreadLocal 版本 ]
 * 
 * <p>
 * 	使用 [ ThreadLocal 版本 ] 上下文处理器需要在全局过滤器或者拦截器内率先调用
 * 	SaTokenContextForThreadLocalStaff.setBox(req, res, sto) 初始化上下文
 * </p>
 *
 * <p> 一般情况下你不需要直接操作此类，因为框架的 starter 集成包里已经封装了完整的上下文操作 </p>
 *
 * @author click33
 * @since 1.16.0
 */
public class SaTokenContextForThreadLocal implements SaTokenContext {

	@Override
	public void setContext(SaRequest req, SaResponse res, SaStorage stg) {
		SaTokenContextForThreadLocalStaff.setModelBox(req, res, stg);
	}

	@Override
	public void clearContext() {
		SaTokenContextForThreadLocalStaff.clearModelBox();
	}

	@Override
	public boolean isValid() {
		return SaTokenContextForThreadLocalStaff.getModelBoxOrNull() != null;
	}

	@Override
	public SaTokenContextModelBox getModelBox() {
		return SaTokenContextForThreadLocalStaff.getModelBox();
	}

}
